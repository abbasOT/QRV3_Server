const admin = require("firebase-admin");
const asciiHelper = require("../common/asciiHelper");
const fs = require("fs");
const PDFDocument = require("pdfkit-table");
const { sendEmailWithAttachment } = require("../util/SendEmail");

function incrementAscii(ascii) {
  const nextAscii = parseInt(ascii, 36) + 1;
  return nextAscii.toString(36).toUpperCase();
}

// if (Object.keys(pinsData).length === 1) {
//   const asciiRef = admin.database().ref('/ascii');
//   const snapshot2 = await asciiRef.once('value');
//   currentAscii = snapshot2.val() || 'AA';
//   currentAscii = incrementAscii(currentAscii);
//   await asciiRef.set(currentAscii);
// }else{
//   console.log(pinData.PinCode.substring(0, 2))
//   currentAscii = pinData.PinCode.substring(0, 2);
// }

const signup = async (req, res) => {
  try {
    const { name, lastName, address, phoneNumber, email, password } = req.body;

    console.log(name, lastName, address, phoneNumber, email, password);

    const prefixedKey = "commercial" + admin.database().ref().push().key;

    let currentAscii = "AA";
    const asciiRef = admin.database().ref("/ascii");
    const snapshot2 = await asciiRef.once("value");
    currentAscii = snapshot2.val() || "AA";
    
    

    //  if (Object.keys(pinsData).length === 1) {

    //   }else{
    //     console.log(pinData.PinCode.substring(0, 2))
    //     currentAscii = pinData.PinCode.substring(0, 2);
    //   }

    const prefixedUserData = {
      [prefixedKey]: {
        name,
        lastName,
        address,
        phoneNumber,
        email,
        password,
        id: prefixedKey,
        status: "inactive",
        SC: currentAscii,
        usercount: "0",
        WelcomMessage:"QR DoorMan"
      },
    };

    await admin.database().ref("/commercial").update(prefixedUserData);
    currentAscii = incrementAscii(currentAscii);
    await asciiRef.set(currentAscii);

    res.status(201).json({ message: "Signup successful", userId: prefixedKey });
  } catch (error) {
    console.error("Error in signup:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log(password);
    // Retrieve user data from /commercialAdmin based on the provided email
    const snapshot = await admin
      .database()
      .ref("/commercial")
      .orderByChild("email")
      .equalTo(email)
      .once("value");
    const userData = snapshot.val();

    if (!userData) {
      // If no user with the provided email is found, return an error
      return res.status(401).json({ error: "Invalid credentials" });
    }

    // Check if the provided password matches the stored password
    const userKey = Object.keys(userData)[0]; // Get the dynamically generated key
    const user = userData[userKey]; // Get the user data using the key

    if (!user || user.password !== password) {
      // If no user with the provided email is found or password doesn't match, return an error
      return res.status(401).json({ error: "Invalid credentials" });
    }

    // If email and password match, consider it a successful login
    res
      .status(200)
      .json({ message: "Login successful", user, userKey, userData: user });
  } catch (error) {
    console.error("Error in login:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const changePassword = async (req, res) => {
  try {
    const { com_prop_id } = req.params;
    const { oldpassword, newpassword } = req.body;

    // Check if the user ID and old password are provided
    if (!com_prop_id || !oldpassword) {
      return res
        .status(400)
        .json({ error: "User ID and old password are required" });
    }

    // Retrieve user data from the database based on the user ID
    const userRef = admin.database().ref(`/commercial/${com_prop_id}`);
    const userSnapshot = await userRef.once("value");

    // Check if the user exists
    if (!userSnapshot.exists()) {
      return res.status(404).json({ error: "User not found" });
    }

    const userData = userSnapshot.val();

    // Check if the old password matches the stored password
    if (userData.password !== oldpassword) {
      return res.status(401).json({ error: "Old password is incorrect" });
    }

    // Update the user's password with the new password
    await userRef.update({ password: newpassword });

    res.status(200).json({ message: "Password changed successfully" });
  } catch (error) {
    console.error("Error in changing password:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const GetComAdmin = async (req, res) => {
  try {
    const { com_prop_id } = req.params;

    // Assuming you have a reference to your database
    const commercialRef = admin.database().ref(`/commercial/${com_prop_id}`);

    // Fetch data from the database
    const snapshot = await commercialRef.once("value");
    const data = snapshot.val();
    const residentsRef = admin
      .database()
      .ref(`/commercial/users/${com_prop_id}/users`);

    // Fetch data from the database
    const snapshot2 = await residentsRef.once("value");
    const residentsData = snapshot2.val();
    let AdminData = [];
    AdminData = {
      userId: {
        name: data.name,
        lname: data.lastName,
        userId: data.id,
      },
    };

    res.status(200).json({ commercialAdmin: data, residentsData, AdminData });
  } catch (error) {
    console.error("Error in fetching residents:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

//find Property

const findProperty = async (req, res) => {
  const { com_prop_id } = req.params;
  const { PropertyId } = req.body;
  console.log(com_prop_id);
  console.log(PropertyId);
  try {
    // Get the property data from the StandByProperties node
    const standByPropertiesRef = admin
      .database()
      .ref(`/StandByProperties/${PropertyId}`);
    const snapshot = await standByPropertiesRef.once("value");

    // Check if the property exists in StandByProperties
    if (!snapshot.exists()) {
      return res.status(404).json({ error: "Property not found by given id" });
    }

    const propertyData = snapshot.val();

    // Remove the property from StandByProperties
    await standByPropertiesRef.remove();

    // Update the status to "active" and save in the commercial node
    const commercialRef = admin.database().ref(`/commercial/${com_prop_id}`);
    const snapshotExsiting = await commercialRef.once("value");
    const existingData = snapshotExsiting.val();

    await commercialRef.update({
      ...existingData,
      ...propertyData,
      status: "active",
    });

    // Respond with success
    res.status(200).json({
      message: "Property moved successfully",
    });
  } catch (error) {
    console.error("Error moving property:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const AddResidents = async (req, res) => {
  const residentsRef = admin.database().ref(`/commercial/waitingusers`);
  const { com_prop_id } = req.params;
  const { email ,name ,lname} = req.body;
  const adminRef = admin.database().ref(`/commercial/${com_prop_id}`);
  const snapshot = await adminRef.once("value");
  const adminData = snapshot.val();

  console.log(name)
  console.log(231)
  console.log(lname)
  try {
    // Fetch all users from waiting users
    const snapshot = await residentsRef.once("value");
    const allUsers = snapshot.val();

    let matchingUser;
    let userId;

    // Iterate through all users to find the matching one
    for (const [key, user] of Object.entries(allUsers)) {
      if (user.email.trim() === email.trim() && user.firstName.trim() === name.trim() && user.lastName.trim() === lname.trim()) {
        user.userId = key;
        user.status = "suspended";
        console.log(user);
        matchingUser = user;
        userId = key;
        break;
      }
    }

    if (!matchingUser) {
      return res.status(404).json({ error: "User not found" });
    } else {
      sendEmailWithAttachment(matchingUser.email);
    }

    const prefixedKey = userId;
    const newUsersRef = admin
      .database()
      .ref(`/commercial/users/${com_prop_id}/users`);
    const newUserNode = {};
    console.log(259 + adminData.propertyId);
    matchingUser.propertyId = adminData.propertyId;
    newUserNode[prefixedKey] = matchingUser;
    await newUsersRef.update(newUserNode);

    if (adminData && adminData.usercount !== undefined) {
      // Increment the usercount property
      adminData.usercount++;

      // Update the value in the database
      adminRef.update({ usercount: adminData.usercount });
    } else {
      // Handle the case where adminData or usercount doesn't exist as expected
      console.error("Invalid data structure or missing usercount property");
    }

    // Remove the user from the old location
    await residentsRef.child(userId).remove();

    const snapshot1 = await newUsersRef.once("value");
    const residentsData = snapshot1.val();

    res.status(200).json({ residents: residentsData });
  } catch (error) {
    console.error("Error in adding resident:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const GetResidents = async (req, res) => {
  try {
    const { com_prop_id } = req.params;

    // Assuming you have a reference to your database
    const residentsRef = admin
      .database()
      .ref(`/commercial/users/${com_prop_id}/users`);

    // Fetch data from the database
    const snapshot = await residentsRef.once("value");
    const residentsData = snapshot.val();

    const commercialRef = admin.database().ref(`/commercial/${com_prop_id}`);

    // Fetch data from the database
    const snapshot2 = await commercialRef.once("value");
    const data = snapshot2.val();

    const activeUsers = Object.entries(residentsData || {})
    .filter(([userId, userData]) => userData.status !== "" && userData.firstName !== "")
    .reduce((acc, [userId, userData]) => {
      acc[userId] = userData;
      return acc;
    }, {});

    console.log(activeUsers)

    res.status(200).json({ residents: activeUsers, status: data.status });
  } catch (error) {
    console.error("Error in fetching residents:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const DeleteResidents = async (req, res) => {
  try {
    const { com_prop_id } = req.params;
    const { userId } = req.params;

    const userRef = admin
      .database()
      .ref(`/commercial/users/${com_prop_id}/users/${userId}`);
    const snapshot = await userRef.once("value");

    if (!snapshot.exists()) {
      return res.status(404).json({ error: "User not found" });
    }
    const userData = snapshot.val();
  //  const {success} =  await moveUserToWaitingUsers("commercial",userId, userData);
    
    // await userRef.update({status: "inactive"})
    await userRef.remove();
    const allusersRef = admin
      .database()
      .ref(`/commercial/users/${com_prop_id}/users`);
    const allusersSnapshot = await allusersRef.once("value");
    const allUsersData = allusersSnapshot.val();
    const activeUsers = Object.entries(allUsersData || {})
  .filter(([userId, userData]) => userData.status !== null)
  .reduce((acc, [userId, userData]) => {
    acc[userId] = userData;
    return acc;
  }, {});


    // console.log(propertiesData);
    res.json({
      message: "user deleted successfully",
      residents: activeUsers,
    });
  } catch (error) {
    console.error("Error deleting :", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
//  moveUserToWaitingUsers

const moveUserToWaitingUsers = async (propType,userId, userData) => {


  try {
if(userData.login !== 0){
  userData.login = "0";
}
if(userData.payment !== null){
  userData.payment =""
}
if(userData.payments){
  delete userData.payments
}

   
    
    // Reference to the waiting users location
    const waitingUsersRef = admin
      .database()
      .ref(`/${propType}/waitingusers/${userId}`);

    // Write user data to waiting users location
    await waitingUsersRef.set(userData);

    return { success: true };
  } catch (error) {
    console.error("Error moving user to waiting users:", error);
    throw error;
  }
};
//

const SuspendResidents = async (req, res) => {
  try {
    const { com_prop_id } = req.params;
    const { userId } = req.params;
    const { status } = req.params;
    console.log(status);
    console.log(userId);

    const UserRef = admin
      .database()
      .ref(`/commercial/users/${com_prop_id}/users`);

    const snapshot = await UserRef.orderByChild("userId")
      .equalTo(userId)
      .once("value");

    if (!snapshot.exists()) {
      return res.status(404).json({ error: "Property user not found" });
    }

    const childSnapshot = snapshot.val();
    const userData = childSnapshot[Object.keys(childSnapshot)[0]];

    // Update the status to "suspended"
    await UserRef.child(Object.keys(childSnapshot)[0]).update({
      status: status,
    });

    const allusersRef = admin
      .database()
      .ref(`/commercial/users/${com_prop_id}/users`);
    const allusersSnapshot = await allusersRef.once("value");
    const allUsersData = allusersSnapshot.val();
    // console.log(propertiesData);
    res.json({
      message: "Property suspended successfully",
      residents: allUsersData,
    });
  } catch (error) {
    console.error("Error in updateProperty:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

//pins

// let currentAscii = snapshot.val() || 'AA';

// Increment the ASCII value (e.g., AA -> AB, ZZ -> AAA)
// currentAscii = incrementAscii(currentAscii);

// Save the updated ASCII value back to the database
// await asciiRef.set(currentAscii);

const AddPins = async (req, res) => {
  try {
    const { com_prop_id } = req.params;
    const { PinCode, PinCodeName } = req.body;
console.log(com_prop_id)
    // Save the pin in the specified reference
    const pinsRef = admin
      .database()
      .ref(`/commercial/AdminPins/${com_prop_id}`);

      const PinsSnapshot = await pinsRef.once('value');
      const pins = PinsSnapshot.val();


      if(pins){

        const pinExists = Object.values(pins).some(pin => pin.PinCode === PinCode);
        if (pinExists) {
          return res.status(400).json({ message: 'Pin code already exists' });
        }
        
      }
      console.log(pins)
  
      // Check if any pin code matches the provided PinCode
    

        const newPinRef = pinsRef.push();
    const newPinId = newPinRef.key;

    const pinData = {
      PinCode,
      PinCodeName,
      pinId: newPinId,
    };

    await newPinRef.set(pinData);

    // Fetch all pins from the reference
    const snapshot = await pinsRef.once("value");
    const pinsData = snapshot.val();
    let currentAscii;
  
    console.log(Object.keys(pinsData).length);

    res.status(201).json({
      message: "Pin created successfully",
      pins: pinsData,
      pinId: newPinRef.key,
      ascii: currentAscii,
    });





  
    // if (Object.keys(pinsData).length === 1) {
    //   const asciiRef = admin.database().ref('/ascii');
    //   const snapshot2 = await asciiRef.once('value');
    //   currentAscii = snapshot2.val() || 'AA';
    //   currentAscii = incrementAscii(currentAscii);
    //   await asciiRef.set(currentAscii);
    // }else{
    //   console.log(pinData.PinCode.substring(0, 2))
    //   currentAscii = pinData.PinCode.substring(0, 2);
    // }

    // Update the ASCII value (e.g., AA -> AB, ZZ -> AAA)
  
  } catch (error) {
    console.error("Error in adding pin:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const GetPins = async (req, res) => {
  try {
    const { com_prop_id } = req.params;

    const PinsRef = admin
      .database()
      .ref(`/commercial/AdminPins/${com_prop_id}`);

    const SCRef = admin.database().ref(`/commercial/${com_prop_id}`);

    const snapshot2 = await SCRef.once("value");
    const SCData = snapshot2.val();
    console.log(SCData.SC);

    // Fetch data from the database
    const snapshot = await PinsRef.once("value");
    const pinsData = snapshot.val();

    res.status(200).json({
      pins: pinsData,
      message: "Pin created successfully",
      SC: SCData.SC,
    });
  } catch (error) {
    console.error("Error in fetching residents:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const DeletePins = async (req, res) => {
  try {
    const { com_prop_id } = req.params;
    const { pinId } = req.params;

    // Reference to the specific pin to delete
    const pinRef = admin
      .database()
      .ref(`/commercial/AdminPins/${com_prop_id}/${pinId}`);

    // Check if the pin exists
    const pinSnapshot = await pinRef.once("value");
    if (!pinSnapshot.exists()) {
      return res.status(404).json({ error: "Pin not found" });
    }

    // Delete the pin
    await pinRef.remove();

    // Fetch all remaining pins from the reference
    const remainingPinsSnapshot = await pinRef.parent.once("value");
    const remainingPinsData = remainingPinsSnapshot.val();

    // Respond with a success message and all remaining pins
    res.status(200).json({
      message: "Pin deleted successfully",
      remainingPins: remainingPinsData,
    });
  } catch (error) {
    console.error("Error in deleting pin:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const UpdatePins = async (req, res) => {
  try {
    const { com_prop_id } = req.params;
    const { pinId } = req.params;
    console.log(pinId);
    const { PinDetails, modifiedPinCode } = req.body;
    console.log(modifiedPinCode);
    // Reference to the specific pin to update
    const pinRef = admin
      .database()
      .ref(`/commercial/AdminPins/${com_prop_id}/${pinId}`);

    // Check if the pin exists
    const pinSnapshot = await pinRef.once("value");
    if (!pinSnapshot.exists()) {
      return res.status(404).json({ error: "Pin not found" });
    }

    // Update the pin
    await pinRef.update({
      PinCode: modifiedPinCode,
      PinCodeName: PinDetails.PinCodeName,
      pinId: pinId,
    });

    // Fetch all updated pins from the reference
    const updatedPinsSnapshot = await pinRef.parent.once("value");
    const updatedPinsData = updatedPinsSnapshot.val();

    // Respond with a success message and all updated pins
    res.status(200).json({
      message: "Pin updated successfully",
      updatedPins: updatedPinsData,
    });
  } catch (error) {
    console.error("Error in updating pin:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

//setTimer

const setTimer = async (req, res) => {
  try {
    const { com_prop_id } = req.params;
    const { ontime, offtime } = req.body;
    console.log(ontime)
    console.log(offtime)

    const commercialSnapshot = await admin
      .database()
      .ref(`/commercial/${com_prop_id}`)
      .once("value");
    const commercialData = commercialSnapshot.val();

    if (commercialData && commercialData.pcbId) {
      const pcbId = commercialData.pcbId;

      console.log(pcbId);

      const PCBRef = admin.database().ref(`/PCB/${pcbId}`);
      await PCBRef.update({
        ontime: ontime,
        offtime: offtime,
      });

      res.status(201).json({
        message: "SetTime successfully",
      });
    } else {
      res.status(404).json({ error: "pcbId not found in the commercial data" });
    }
  } catch (error) {
    console.error("Error in adding pin:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Intercom id

const AddInterComId = async (req, res) => {
  try {
    const { com_prop_id } = req.params;
    const { IntercomId } = req.body;
    console.log(IntercomId);

    const pcbsRef = admin
      .database()
      .ref(`/superadminit38XGIc27Q8HDXoZwe1OzI900u1/StandByPCBs/${IntercomId}`);
    const pcbsSnapshot = await pcbsRef.once("value");
    const pcbsData = pcbsSnapshot.val();
    // Check if the PCB with the specified IntercomId exists
    if (!pcbsSnapshot.exists()) {
      return res.status(404).json({ error: "PCB not found" });
    }

    const commercialRef = admin.database().ref(`/commercial/${com_prop_id}`);
    const snapshotExsiting = await commercialRef.once("value");
    const existingData = snapshotExsiting.val();

    if (existingData.pcbId) {
      // If pcbId already exists, send a response
      return res
        .status(400)
        .json({ error: "PCB ID already exists", pcbId: existingData.pcbId });
    }
    await commercialRef.update({
      ...existingData,
      pcbId: IntercomId,
      pcbStatus: "online",
    });

    const updatedsnapshot = await commercialRef.once("value");
    const updatedData = updatedsnapshot.val();
    await pcbsRef.remove();

    const PCBRef = admin.database().ref(`/PCB/${IntercomId}`);
    pcbsData.propertyId = com_prop_id;
    pcbsData.door="0";
    pcbsData.light="0";
    await PCBRef.set(pcbsData);

    res.status(200).json({
      message: "InterComId updated successfully",
      commercialData: updatedData,
    });
  } catch (error) {
    console.error("Error in updating pin:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const deleteIntercomId = async (req, res) => {
  try {
    const { com_prop_id } = req.params;

    // Reference to the specific commercial property
    const IntercomRef = admin.database().ref(`/commercial/${com_prop_id}`);

    // Retrieve the commercial property data
    const commercialSnapshot = await IntercomRef.once("value");
    let commercialData = commercialSnapshot.val();

    if (!commercialData) {
      // If the commercial property doesn't exist, send a not found response
      return res.status(404).json({ error: "Commercial property not found" });
    }

    // Check if the property named pcbId exists
    if (commercialData.pcbId) {
      const pcbId = commercialData.pcbId;
      const pcbStatus = commercialData.pcbStatus;
      console.log(pcbId);
      // Remove the property named pcbId
      await IntercomRef.child(pcbId).remove();
      // await IntercomRef.child(pcbStatus).remove();

      // Check if the pcbId field exists before removing it from commercialData
      if (commercialData.hasOwnProperty("pcbId")) {
        const PCBRef = admin.database().ref(`/PCB/${commercialData.pcbId}`);
        await PCBRef.remove();

        delete commercialData.pcbId;
        delete commercialData.pcbStatus;

        await IntercomRef.set(commercialData);
        const updatedSnapshot = await IntercomRef.once("value");
        commercialData = updatedSnapshot.val();
        // console.log(commercialData)
      }
      // Respond with success message
      res.status(200).json({
        message: "InterComId deleted successfully",
        commercialData,
      });
    } else {
      // If pcbId doesn't exist, send a not found response
      res.status(404).json({ error: "PCB ID not found" });
    }
  } catch (error) {
    console.error("Error in deleting InterComId:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

//

const updateUser = async (req, res) => {
  try {
    const { com_prop_id } = req.params;
    const { name, lastName, address, phoneNumber } = req.body;

    // Reference to the specific user to update
    const userRef = admin.database().ref(`/commercial/${com_prop_id}`);

    // Check if the user exists
    const userSnapshot = await userRef.once("value");
    if (!userSnapshot.exists()) {
      return res.status(404).json({ error: "User not found" });
    }

    // Update user information
    await userRef.update({
      name,
      lastName,
      address,
      phoneNumber,
    });
    const updatedUserSnapshot = await userRef.once("value");
    const updatedUserData = updatedUserSnapshot.val();
    // Respond with a success message
    res
      .status(200)
      .json({ message: "User updated successfully", user: updatedUserData });
  } catch (error) {
    console.error("Error updating user:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const deleteUser = async (req, res) => {
  try {
    const { com_prop_id } = req.params;

    // Your logic to delete the user, for example:
    const userRef = admin.database().ref(`/commercial/${com_prop_id}`);

    await deleteUsers("commercial",com_prop_id);

    await userRef.remove();

    res.status(200).json({ message: "User deleted successfully" });
  } catch (error) {
    console.error("Error deleting user:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

async function deleteUsers(property_type,prop_id) {

  const AdminUserRef = admin
    .database()
    .ref(`/${property_type}/users/${prop_id}/users`);
  const usersSnapshot = await AdminUserRef.once("value");
  const users = usersSnapshot.val();

  if (users) {
    await Promise.all(Object.keys(users).map(async (userId) => {
      const user = users[userId];
      console.log(user); // Just for debugging, you can remove this line if not needed
      

      const UserRef = admin
        .database()
        .ref(`/${property_type}/users/${prop_id}/users/${userId}`);

        await UserRef.remove();

        // if(changeUserStatus) {
        //     await UserRef.update({ status: status });
        // }else{
        //   const {success} =  await moveUserToWaitingUsers(property_type,userId, user);
        //   await UserRef.remove(); 
        // }
        
      
    }));
  }
}

// Get Resident With PCB Id
const VisitorData = async (req, res) => {
  try {
    const { pcbId } = req.params;
    console.log(pcbId);
    let data = [];
    // Assuming you have a reference to your database
    const residentsRef = admin.database().ref(`/PCB/${pcbId}`);

    const snapshot = await residentsRef.once("value");
    const residentsData = snapshot.val();

    // Check if residentsData exists
    if (!residentsData) {
      return res.status(404).json({ error: "Residents data not found" });
    }

    // Check if the propertyId field exists
    const prop_id = residentsData.propertyId;
    let proptype;
    if (isCommercialProperty(prop_id)) {
      console.log(`${prop_id} is a commercial property.`);
      // Handle commercial property case
      proptype = "commercial";
      const AdminRef = admin.database().ref(`/commercial/${prop_id}`);
      const AdminRefsnapshot = await AdminRef.once("value");
      const AdminData = AdminRefsnapshot.val();
      const AllresidentsRef = admin
        .database()
        .ref(`/commercial/users/${prop_id}/users`);

      const Allresidentssnapshot = await AllresidentsRef.once("value");
      const AllresidentsData = Allresidentssnapshot.val();
      let activeUsers = [];
      if (AllresidentsData) {
        data = {
          userId: {
            name: AdminData.name,
            lname: AdminData.lastName,
            userId: AdminData.id,
          },
        };
        activeUsers = Object.values(AllresidentsData)
          .filter((user) => user.status === "active")
          // .sort((a, b) => a.name.localeCompare(b.name));
        res.status(200).json({
          residents: activeUsers,
          propId: prop_id,
          AdminData,
          proptype,
          data,
          residentsData,
        });
      } else {
        res.status(200).json({
          residents: activeUsers,
          propId: prop_id,
          AdminData,
          proptype,
          data,
          residentsData,
        });
      }
    } else {
      console.log(`${prop_id} is a residential property.`);

      const AdminRef = admin.database().ref(`/residential/${prop_id}`);
      const AdminRefsnapshot = await AdminRef.once("value");
      const AdminData = AdminRefsnapshot.val();
      data = {
        userId: {
          name: AdminData.name,
          lname: AdminData.lastName,
          userId: AdminData.id,
        },
      };
      proptype = "residential";

      res.status(200).json({
        residents: [],
        propId: prop_id,
        AdminData,
        proptype,
        data,
        residentsData,
      });
    }

    // console.log(com_id)
    if (!prop_id) {
      return res
        .status(404)
        .json({ error: "Property ID not found in residents data" });
    }
  } catch (error) {
    console.error("Error in fetching residents:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

function isCommercialProperty(propertyId) {
  return propertyId.startsWith("c");
}
// Open door With Pin
const findPin = (pinsData, pin) => {
  return Object.entries(pinsData).find(
    ([pinId, pinData]) => pinData.PinCode === pin
  );
};

const findPinInAnotherNode = async (matchingPinId, usersData, propId) => {
  try {
    if (usersData) {
      // Iterate over each user ID asynchronously
      for (const userId of Object.keys(usersData)) {
        const userData = usersData[userId];
        // Check each user for the matching pin
        const matchingUserPin = findUserByPin(userData, matchingPinId);
        if (matchingUserPin) {
          console.log(`Matching user found with ID ${userId}.`);
          return { userId, userData, matchingUserPin };
        }
      }

      // No matching user found
      return null;
    } else {
      // No users found for the specified comId in the second node
      return null;
    }
  } catch (error) {
    console.error("Error in finding pin in another node:", error);
    return null;
  }
};

const AccessDoorWithPin = async (req, res) => {
  try {
    const { comId } = req.params;
    const { pin } = req.body;
    let pcbId;

    // Assuming you have a reference to your database
    const PinRef = admin.database().ref(`commercial/AdminPins/${comId}`);
    const snapshot = await PinRef.once("value");
    const pinsData = snapshot.val();

    const AdminRef = admin.database().ref(`commercial/${comId}`);
    const Adminsnapshot = await AdminRef.once("value");
    const AdminData = Adminsnapshot.val();
    console.log(AdminData.pcbId);
    pcbId = AdminData.pcbId;

    const EventRef = admin.database().ref(`commercial/events/${comId}`);
    let response_msg = "";
    if (pinsData) {
      
      console.log(800);
      const matchingPin = findPin(pinsData, pin);
      if (matchingPin && AdminData.status === "active") {
     
        const updateResult = await updateDoorProperty(pcbId);
        if (updateResult.status === 200) {
          // await TpinRef.child(matchingTpin.key).remove();
           console.log(matchingPin)
           const pinData = matchingPin[1];
  
           // Dynamically access the PinCodeName property
           const pinCodeName = pinData['PinCodeName'];
           console.log(pinCodeName);
           console.log(985) 
          const eventMessage = `${pinCodeName} .`;
          logDoorOpenEvent(EventRef, eventMessage, "O");
          return res.status(200).json({
            message: "Pin matched successfully",
            sensorCheck: updateResult.sensorCheck,
          });
        } else if (updateResult.status === 400) {
          return res.status(updateResult.status).json({
            error: updateResult.message,
            sensorCheck: updateResult.sensorCheck,
          });
        }
      } else if (matchingPin && AdminData.status === "inactive") {
        response_msg = "Sorry you cannot access the door";
        console.log("in else");
      } else {
        response_msg = "Wrong Pin Entered";
      }
    }

    const FindUsersPinRef = admin
      .database()
      .ref(`commercial/users/${comId}/users`);
    const UsersPinsnapshot = await FindUsersPinRef.once("value");
    const usersData = UsersPinsnapshot.val();

    if (usersData) {
      const matchingUser = await findPinInAnotherNode(pin, usersData, comId);

      if (matchingUser && matchingUser.userData.status === "active") {
        const { matchingUserPin, userData } = matchingUser;
        console.log(987);
        console.log(matchingUser.userData.status);
        const updateResult = await updateDoorProperty(pcbId);

        if (updateResult.status === 200) {
          if (matchingUser.matchingUserPin.type === "T") {
            const RemovePinRef = admin
              .database()
              .ref(
                `commercial/users/${comId}/users/${matchingUser.userId}/Tpins`
              );
            await RemovePinRef.child(
              matchingUser.matchingUserPin.pinName
            ).remove();
          }
          console.log(1001)
          const userId=userData.userId;
          console.log(matchingUserPin.pinData.name);
          // The door was successfully updated
          const eventType = matchingUserPin.type === "Ppin" ? "" : "'s visitor";
          //admin events
          logDoorOpenEvent(
            EventRef,
            `${userData.firstName}'s visitor.`,
            matchingUserPin.type
          );
          //user events
          const EventForUserRef = admin.database().ref(`commercial/users/${comId}/users/${userId}/myevents`);
          logDoorOpenEventForUser(EventForUserRef,matchingUserPin.pinData.name,matchingUserPin.type)

          res.status(200).json({
            message: "Pin matched successfully",
            sensorCheck: updateResult.sensorCheck,
          });
        } else if (updateResult.status === 400) {
          res.status(updateResult.status).json({
            error: updateResult.message,
            sensorCheck: updateResult.sensorCheck,
          });
        }
      } else if (
        matchingUser &&
        (matchingUser.userData.status === "suspended" ||
          matchingUser.userData.status === "inactive")
      ) {
        res.status(404).json({ error: "Sorry you cannot access the door" });
      } else {
        res.status(404).json({ error: response_msg });
      }
    } else {
      res.status(404).json({ error: "Wrong Pin Entered" });
    }
  } catch (error) {
    console.error("Error in accessing pins:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};


// Add event
const logDoorOpenEvent = async (EventRef, eventMessage, type) => {
console.log("1038",type)
  try {
    await EventRef.push().set({
      timestamp: admin.database.ServerValue.TIMESTAMP,
      message: eventMessage,
      eventType: type,
    });
    return { message: "success" };
  } catch (error) {
    console.error("Error logging door open event:", error);
    return { message: "error" };
  }
};
const logDoorOpenEventForUser = async (EventRef, eventMessage, type) => {
  console.log("1060",type)
    try {
      await EventRef.push().set({
        timestamp: admin.database.ServerValue.TIMESTAMP,
        message: eventMessage,
        eventType: type,
      });
      return { message: "success" };
    } catch (error) {
      console.error("Error logging door open event:", error);
      return { message: "error" };
    }
  };

const updateDoorProperty = async (pcbId) => {
  console.log(pcbId);
  console.log("pcb Id");
  try {
    const PCBRef = admin.database().ref(`/PCB/${pcbId}`);

    // Get the current PCB data
    const pcbSnapshot = await PCBRef.once("value");
    const pcbData = pcbSnapshot.val();
    console.log(pcbData);
    if (pcbData && pcbData.hasOwnProperty("sensor") && pcbData.sensor === "1") {
      // Check if 'sensor' property exists and its value is equal to 1
      // await PCBRef.update({ door: "1" });
      await admin.database().ref(`/PCB/${pcbId}/door`).set("1");

      setTimeout(async () => {
        await admin.database().ref(`/PCB/${pcbId}/door`).set("0");
      }, 1000);

      console.log(`Door property for PCB ${pcbId} updated to 1 successfully.`);
      return {
        status: 200,
        message: "Door opened successfully",
        sensorCheck: true,
      };
    } else {
      return {
        status: 400,
        message: "Sensor check failed",
        sensorCheck: false,
      };
    }
  } catch (error) {
    console.error(`Error updating door property for PCB ${pcbId}:`, error);
    return { status: 500, message: "Internal Server Error" };
  }
};
//
const findUserByPin = (userData, pin) => {
  // Check Ppins node
  console.log(1089,"inside findUserByPin func");
  for (const pinName in userData.Ppins) {
    const pinData = userData.Ppins[pinName];

    if (pinData.pin === pin) {
      console.log(1094);
      return { pinName, pinData, type: "P" };
    }
  }

  // Check Tpins node

  for (const pinName in userData.Tpins) {
    const pinData = userData.Tpins[pinName];

    if (pinData.pin === pin) {
      console.log(1105,"T");
      return { pinName, pinData, type: "T" };
    }
  }

  return null;
};
//OpenDoorWithPinResidential

const findPinforRedidentialNode = async (propId, matchingPinId) => {
  try {
    const FindPinRef = admin
      .database()
      .ref(`residential/users/${propId}/users`);
    const snapshot = await FindPinRef.once("value");
    const usersData = snapshot.val();

    if (usersData) {
      for (const userId of Object.keys(usersData)) {
        const userData = usersData[userId];

        console.log(1126);
        const matchingUserPin = findUserByPin(userData, matchingPinId);

        if (matchingUserPin) {
          if (matchingUserPin.type === "T") {
            console.log(1131);
            const RemovePinRef = admin
              .database()
              .ref(`residential/users/${propId}/users/${userId}/Tpins`);
            await RemovePinRef.child(matchingUserPin.pinName).remove();
            console.log(929);
          }
          console.log(`Matching user found with ID ${userId}.`);
          return { userId, userData, matchingUserPin };
        }
      }
      return null;
    } else {
      // No users found for the specified comId in the second node
      return null;
    }
  } catch (error) {
    console.error("Error in finding pin in another node:", error);
    return null;
  }
};

function ResfindPin(pinsData, pinToFind) {
  for (const key in pinsData) {
    if (pinsData.hasOwnProperty(key)) {
      const pin = pinsData[key];

      if (pin.pin === pinToFind) {
        return { pin, key };
      }
    }
  }
  return null;
}

const OpenDoorWithPinResidential = async (req, res) => {
  try {
    const { propId } = req.params;
    const { pin } = req.body;

    const PpinRef = admin.database().ref(`residential/users/${propId}/Ppins`);
    const TpinRef = admin.database().ref(`residential/users/${propId}/Tpins`);
    const snapshotPpin = await PpinRef.once("value");
    const pinsDataPpin = snapshotPpin.val();
    const snapshotTpin = await TpinRef.once("value");
    const pinsDataTpin = snapshotTpin.val();
    let AdminRef = admin.database().ref(`residential/${propId}`);
    let Adminsnapshot = await AdminRef.once("value");
    let matchingPpin = ResfindPin(pinsDataPpin, pin);
    let matchingTpin = ResfindPin(pinsDataTpin, pin);
    let ResidentName;
    let response_msg = "";
    const ResUserData = Adminsnapshot.val();
   
    console.log(1207);

    if (matchingPpin) {
      if (matchingPpin && ResUserData.status === "active") {
        console.log("PPin matched successfully");
        console.log(ResUserData.status)
        console.log("user");

        ResidentName = ResUserData.UserName;
        if (ResUserData?.hasOwnProperty("pcbId")) {
          const updateResult = await updateDoorProperty(ResUserData.pcbId);
          // console.log(1134);

          if (updateResult.status === 200) {
            const EventRef = admin
              .database()
              .ref(`residential/${propId}/events`);
            const status = await logDoorOpenEvent(
              //   //${ResUserData.UserName }
              EventRef,
              `${ResidentName}'s visitor`,"P"
            );
            console.log(matchingPpin)
            console.log(1230);
           
            const EventForUserRef = admin.database().ref(`residential/${propId}/myevents`);
           
            logDoorOpenEventForUser(EventForUserRef,matchingPpin.pin.name,"P")
 // const EventForUserRef = admin.database().ref(`residential/users/${comId}/users/${userId}/myevents`);
            res.status(200).json({
              message: "Pin matched successfully",
              sensorCheck: updateResult.sensorCheck,
            });
          } else {
            res.status(updateResult.status).json({
              error: updateResult.message,
              sensorCheck: updateResult.sensorCheck,
            });
          }
        }
      } else if (matchingPpin && ResUserData.status === "inactive") {
        response_msg = "Sorry you cannot access the door";
        console.log("in else");
      } else {
        response_msg = "Wrong Pin Entered";
      }
    } else if (matchingTpin && ResUserData.status === "active") {
      console.log(ResidentName);
      console.log(1255);
      if (matchingTpin) {
        const ResUserData = Adminsnapshot.val();

        if (ResUserData?.hasOwnProperty("pcbId")) {
          const updateResult = await updateDoorProperty(ResUserData.pcbId);

          if (updateResult.status === 200) {
            const EventRef = admin
              .database()
              .ref(`residential/${propId}/events`);
            const status = await logDoorOpenEvent(
              EventRef,
              `${ResUserData.UserName}'s Visitor `,"T"
            );

            const EventForUserRef = admin.database().ref(`residential/${propId}/myevents`);
            console.log(matchingTpin.pin.name)
            logDoorOpenEventForUser(EventForUserRef,matchingTpin.pin.name,"T")
            console.log("residential TPin matched successfully");

            await TpinRef.child(matchingTpin.key).remove();

            console.log("removed pin");
            res.status(200).json({
              message: "Pin matched successfully",
              sensorCheck: updateResult.sensorCheck,
            });
          } else {
            res.status(updateResult.status).json({
              error: updateResult.message,
              sensorCheck: updateResult.sensorCheck,
            });
          }
        }
      }else if (matchingTpin && ResUserData.status === "inactive") {
        response_msg = "Sorry you cannot access the door";
        console.log("in else");
      } else {
        response_msg = "Wrong Pin Entered";
      }
    } else {
      const matchingUser = await findPinforRedidentialNode(propId, pin);
      console.log(matchingUser.userId);
      if (matchingUser && matchingUser.userData.status === "active") {
        const { matchingUserPin, userData } = matchingUser;

        const ResUserData = Adminsnapshot.val();
        if (ResUserData?.hasOwnProperty("pcbId")) {
          const updateResult = await updateDoorProperty(ResUserData.pcbId);

          if (updateResult.status === 200) {
            const eventType =
              matchingUserPin.type === "Ppin" ? "" : "'s Visitor";
            const EventRef = admin
              .database()
              .ref(`residential/${propId}/events`);

            const status = await logDoorOpenEvent(
              EventRef,
              `${userData.firstName}${eventType} `,matchingUserPin.type
            );
             const userId =matchingUser.userId;
             
            const EventForUserRef = admin.database().ref(`residential/users/${propId}/users/${userId}/myevents`);
            logDoorOpenEventForUser(EventForUserRef,matchingUserPin.pinData.name,matchingUserPin.type)
            // console.log(matchingUserPin.pinData.name);

            res.status(200).json({
              message: "Pin matched successfully",
              sensorCheck: updateResult.sensorCheck,
            });
          } else {
            res.status(updateResult.status).json({
              error: updateResult.message,
              sensorCheck: updateResult.sensorCheck,
            });
          }
        }
      } else if (
        matchingUser &&
        (matchingUser.userData.status === "suspended" ||
          matchingUser.userData.status === "inactive")
      ) {
        res.status(404).json({ error: "Sorry you cannot access the door" });
      } else {
        res.status(404).json({ error: response_msg });
      }
    } //
  } catch (error) {
    console.error("Error in accessing pins:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

//Welcome Message
const WelcomeMessage = async (req, res) => {
  try {
    const { com_prop_id } = req.params;
    const { WelcomMessage } = req.body;

    // Assuming you have a reference to your database
    const CommercialRef = admin.database().ref(`commercial/${com_prop_id}`);

    // Fetch existing data
    const snapshot = await CommercialRef.once("value");
    const CommercialData = snapshot.val();

    if (CommercialData) {
      // Update the CommercialData with the WelcomeMessage
      const updatedCommercialData = {
        ...CommercialData,
        WelcomMessage: WelcomMessage,
      };

      // Update the data in the database
      await CommercialRef.update(updatedCommercialData);

      res.status(200).json({
        message: "Welcome message updated successfully",
        commercialData: updatedCommercialData,
      });
    } else {
      res.status(404).json({ error: "Commercial data not found" });
    }
  } catch (error) {
    console.error("Error in updating welcome message:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
const SaveBrightness = async (req, res) => {
  try {
    const { com_prop_id } = req.params;
    const { brightness } = req.body;
    console.log(brightness);
    // Assuming you have a reference to your database
    const CommercialRef = admin.database().ref(`commercial/${com_prop_id}`);

    // Fetch existing data
    const snapshot = await CommercialRef.once("value");
    const CommercialData = snapshot.val();

    if (CommercialData) {
      // Update the CommercialData with the WelcomeMessage
      const updatedCommercialData = {
        ...CommercialData,
        brightness: brightness,
      };

      // Update the data in the database
      await CommercialRef.update(updatedCommercialData);

      res.status(200).json({
        message: "Opacity updated successfully",
        commercialData: updatedCommercialData,
      });
    } else {
      res.status(404).json({ error: "Commercial data not found" });
    }
  } catch (error) {
    console.error("Error in updating welcome message:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const UploadWallpaper = async (req, res) => {
  try {
    const { com_prop_id } = req.params;

    if (!req.file) {
      return res.status(400).json({ error: "No image provided" });
    }

    const filePath = req.file.path;
    console.log(filePath);
    const destinationPath = "images/" + req.file.originalname;

    const bucket = admin.storage().bucket();
    await bucket.upload(filePath, {
      destination: destinationPath,
      metadata: {
        contentType: req.file.mimetype,
      },
    });

    const imageURL = await bucket
      .file(destinationPath)
      .getSignedUrl({
        action: "read",
        expires: "03-01-2500",
      })
      .then((result) => result[0]);

    // Assuming you have a reference to your database
    const commercialRef = admin.database().ref(`commercial/${com_prop_id}`);

    // Fetch existing data
    const snapshot = await commercialRef.once("value");
    const commercialData = snapshot.val();

    if (commercialData) {
      // Update the CommercialData with the image URL
      const updatedCommercialData = {
        ...commercialData,
        wallpaper: imageURL, // Add the image URL to your data
      };

      // Update the data in the database
      await commercialRef.update(updatedCommercialData);

      res.status(200).json({
        message: "Image uploaded and database updated successfully",
        commercialData: updatedCommercialData,
      });
    } else {
      res.status(404).json({ error: "Commercial data not found" });
    }
  } catch (error) {
    console.error("Error in updating welcome message:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const downloadQR = async (req, res) => {
  try {
    const { pcbId } = req.params;
    console.log(pcbId);
    const PCBRef = admin.database().ref(`/PCB/${pcbId}`);
    const snapshot = await PCBRef.once("value");
    const pcbData = snapshot.val();
    console.log(pcbData);
    if (pcbData) {
      pcbData.QRurl;
      res.status(200).json({
        message: "Download QR",
        pcbData,
      });
    } else {
      res.status(404).json({ error: "PCB data not found" });
    }
  } catch (error) {
    console.error("Error in downloading QR code:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const GetEvents = async (req, res) => {
  try {
    const { com_prop_id } = req.params;
   
    const EventRef = admin.database().ref(`/commercial/events/${com_prop_id}`);
    const snapshot = await EventRef.once("value");
    const EventData = snapshot.val();

    console.log(EventData);
    if (EventData) {
      res.status(200).json({
        message: "get Events",
        EventData,
      });
    } else {
      res.status(404).json({ error: "PCB data not found" });
    }
  } catch (error) {
    console.error("Error in downloading QR code:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
const document = new PDFDocument({ margin: 30, size: "A4" });
const exportPdf = async (req, res) => {
  try {
    const { com_prop_id } = req.params;
    const { fromDate, toDate } = req.body;

    console.log(com_prop_id);
    console.log(fromDate);
    console.log(toDate);

    const EventRef = admin.database().ref(`/commercial/events/${com_prop_id}`);
    const snapshot = await EventRef.once("value");
    const EventData = snapshot.val();

    // await generatePdf(EventData, fromDate, toDate);
    const data = [];

    for (const eventId in EventData) {
      const event = EventData[eventId];
      const timestamp = new Date(event.timestamp);

      if (timestamp >= new Date(fromDate) && timestamp <= new Date(toDate)) {
        data.push([event.message || "", timestamp.toLocaleString()]);
      }
    }

    console.log(data);
    if (EventData) {
      res.status(200).json({
        message: "get Events",
        data,
      });
    } else {
      res.status(404).json({ error: "PCB data not found" });
    }
  } catch (error) {
    console.error("Error in downloading QR code:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};



const generateAscci = async (req, res) => {
  try {
    const asciiRef = admin.database().ref("/ascii");
    const snapshot = await asciiRef.once("value");
    let currentAscii = snapshot.val() || "AA";
    await asciiRef.set(currentAscii);
    // currentAscii = incrementAscii(currentAscii);
    res.json({ ascii: currentAscii });
  } catch (error) {
    console.error("Error generating ASCII:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const IncrementAscci = async (req, res) => {
  try {
    const asciiRef = admin.database().ref("/ascii");
    const snapshot = await asciiRef.once("value");
    let currentAscii = snapshot.val() || "AA";
    currentAscii = incrementAscii(currentAscii);
    await asciiRef.set(currentAscii);

    console.log(currentAscii);
    res.json({ ascii: currentAscii });
  } catch (error) {
    console.error("Error generating ASCII:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

function incrementAscii(ascii) {
  let firstChar = ascii[0];
  let secondChar = ascii[1];

  // Increment the second character
  if (secondChar === "Z") {
    secondChar = "A";

    // Increment the first character
    firstChar = String.fromCharCode(firstChar.charCodeAt(0) + 1);

    // Ensure the first character is a letter
    if (!/[A-Z]/.test(firstChar)) {
      // If it's not a letter, set it back to 'A'
      firstChar = "A";
    }
  } else {
    // Increment the second character normally
    secondChar = String.fromCharCode(secondChar.charCodeAt(0) + 1);
  }

  return firstChar + secondChar;
}

const createToken = async (req, res) => {
  try {
    // Get the token from the request body
    const { randomString } = req.body;

    // Save the token as a new child node under the "tokens" node in the Firebase Realtime Database
    const tokensRef = admin.database().ref(`/tokens`);
    await tokensRef.child(randomString).set({ userCount: 1 });

    res.json({ success: true });
  } catch (error) {
    console.error("Error saving token:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const deleteToken = async (req, res) => {
  try {
    // Get the token from the request parameters
    const { token } = req.params;
    console.log(token);

    // Create a reference to the token in the Firebase Realtime Database
    const tokensRef = admin.database().ref(`/tokens/${token}`);

    // Remove the token from the database
    await tokensRef.remove();

    // Send a success response
    res.status(200).json({ message: "Token deleted successfully" });
  } catch (error) {
    console.error("Error deleting token:", error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = {
  signup,
  login,
  changePassword,
  GetComAdmin,
  //find property
  findProperty,
  //residents
  AddResidents,
  GetResidents,
  DeleteResidents,
  SuspendResidents,
  //pins
  AddPins,
  GetPins,
  DeletePins,
  UpdatePins,
  //setTimer
  setTimer,
  // Intercom
  AddInterComId,
  deleteIntercomId,
  //profile update
  updateUser,
  deleteUser,
  // Get Resident With PCB Id
  VisitorData,
  WelcomeMessage,
  UploadWallpaper,
  downloadQR,
  SaveBrightness,
  //Open Door with Pin code ,
  AccessDoorWithPin,
  OpenDoorWithPinResidential,
  // Events
  GetEvents,
  exportPdf,
  // Generate Ascci
  generateAscci,
  IncrementAscci,
  // create Token
  createToken,
  deleteToken,
};

// const AddResidents = async (req, res) => {
//   try {
//     const { com_prop_id } = req.params;

//     const residentsRef = admin
//       .database()
//       .ref(`/commercial/users/${com_prop_id}/users`);

//     // Extract data from the request body
//     const { name, lname, email, status } = req.body;
//     console.log(`${name}  ${lname} ${email} ${status}`);

//     // Push a new resident to the 'residents' collection
//     const newResidentRef = residentsRef.push({
//       name,
//       lname,
//       email,
//       status,
//     });
//     const userId = newResidentRef.key;
//     const residentDataWithUserId = {
//       userId,
//       name,
//       lname,
//       email,
//       status,
//     };

//     // Update the pushed data with the userId
//     newResidentRef.set(residentDataWithUserId);

//     const Allresidents = admin
//       .database()
//       .ref(`/commercial/users/${com_prop_id}/users`);

//     // Fetch data from the database
//     const snapshot = await Allresidents.once("value");
//     const residentsData = snapshot.val();

//     res.status(201).json({
//       message: "Resident added successfully",
//       residents: residentsData,
//     });
//   } catch (error) {
//     console.error("Error in adding resident:", error);
//     res.status(500).json({ error: "Internal Server Error" });
//   }
// };


// const generatePdf = async (EventData, fromDate, toDate) => {
//   return new Promise((resolve, reject) => {
//     const doc = new PDFDocument();
//     const fileName = `events.pdf`;
//     const stream = fs.createWriteStream(fileName);
//     doc.pipe(stream);

//     const tableData = [];

//     for (const eventId in EventData) {
//       const event = EventData[eventId];
//       const timestamp = new Date(event.timestamp);

//       if (timestamp >= new Date(fromDate) && timestamp <= new Date(toDate)) {
//         tableData.push([event.message || "", timestamp.toLocaleString()]);
//       }
//     }

//     const table = {
//       headers: ["Event Message", "Timestamp"],
//       rows: tableData,
//     };

//     console.log(table);

//     doc.on("pageAdded", () => {
//       doc.table(table, { columnsSize: [200, 200] });
//     });

//     doc.addPage();

//     doc.end();

//     stream.on("finish", () => {
//       console.log(`PDF generated: ${fileName}`);
//       resolve(); // Resolve the promise when PDF generation is complete
//     });

//     stream.on("error", (error) => {
//       console.error("Error generating PDF:", error);
//       reject(error); // Reject the promise if there is an error
//     });
//   });
// };